# README

Downlowaded the GC covariate (CDGC62FL) manually from the DHS https://dhsprogram.com/data/dataset/Congo-Democratic-Republic_Standard-DHS_2013